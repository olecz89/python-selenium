# README #

This repository is an example of how to write well-structured Selenium tests using Page Object Pattern in Python. 

### Contents ###

* Simple forum application used as an application under tests.
* Set of Selenium tests in python 

### Contact ###

* If you have questions aboute the code you can write to me: mkoncikowski@gmail.com