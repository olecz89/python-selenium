FORUM_URL = 'http://koncikowski.pl/forum'

DB_CONF = {
    'host': 'serwer1506500.home.pl',
    'database': '18505037_forum',
    'user': '18505037_forum',
    'password': 'O*PcNI37CGyZ'
}
