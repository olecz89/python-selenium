import unittest

from tests.browser import Browser


class CategoryTest(unittest.TestCase):
    def setUp(self):
        self.browser = Browser()
        self.driver = self.browser.start()

    def test_creating_category_should_succeed(self):
        # given

        # when

        # then
        pass

    def test_creating_category_with_regular_user_should_fail(self):
        # given

        # when

        # then
        pass

    def test_displaying_created_category_on_index_should_succeed(self):
        # given

        # when

        # then
        pass

    def test_opening_newly_created_category_should_succeed(self):
        # given

        # when

        # then
        pass

    def test_displaying_link_to_last_topic_on_index_page_should_succeed(self):
        # given

        # when

        # then
        pass

    def tearDown(self):
        self.browser.stop()
