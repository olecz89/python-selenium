import unittest

from tests.browser import Browser


class SignUpTest(unittest.TestCase):
    def setUp(self):
        self.browser = Browser()
        self.driver = self.browser.start()

    def test_creating_user_should_succeed(self):
        # given

        # when

        # then
        pass

    def test_creating_two_identical_users_should_fail(self):
        # given

        # when

        # then
        pass

    def test_creating_user_without_username_should_fail(self):
        # given

        # when

        # then
        pass

    def test_entering_two_different_passwords_should_fail(self):
        # given

        # when

        # then
        pass

    def tearDown(self):
        self.browser.stop()
