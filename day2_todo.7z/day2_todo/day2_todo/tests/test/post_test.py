import unittest

from tests.browser import Browser


class PostTest(unittest.TestCase):
    def setUp(self):
        self.browser = Browser()
        self.driver = self.browser.start()

    def test_creating_post_should_succeed(self):
        # given

        # when

        # then
        pass

    def test_opening_topic_with_newly_created_post_should_succeed(self):
        # given

        # when

        # then
        pass

    def test_adding_new_post_when_not_logged_in_should_fail(self):
        # given

        # when

        # then
        pass

    def test_number_of_posts_in_newly_created_topic_should_be_correct(self):
        # given

        # when

        # then
        pass

    def test_creating_post_with_newly_created_user_should_succeed(self):
        # given

        # when

        # then
        pass

    def test_posting_to_topic_created_by_another_user_should_succeed(self):
        # given

        # when

        # then
        pass

    def tearDown(self):
        self.browser.stop()
