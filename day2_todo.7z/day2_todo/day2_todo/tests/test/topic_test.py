import unittest

from tests.browser import Browser


class TopicTest(unittest.TestCase):
    def setUp(self):
        self.browser = Browser()
        self.driver = self.browser.start()

    def test_creating_topic_should_should_succeed(self):
        # given

        # when

        # then
        pass

    def test_opening_newly_created_topic_should_succeed(self):
        # given

        # when

        # then
        pass

    def tearDown(self):
        self.browser.stop()
