import unittest

import tests.browser


class SignInTest(unittest.TestCase):
    def setUp(self):
        self.browser = Browser()
        self.driver = self.browser.start()

    def test_logging_in_should_succeed(self):
        # given

        # when

        # then
        pass

    def test_logging_in_with_invalid_user_should_fail(self):
        # given

        # when

        # then
        pass

    def test_logging_in_with_fake_data_should_fail(self):
        # given

        # when

        # then
        pass

    def tearDown(self):
        self.browser.stop()
