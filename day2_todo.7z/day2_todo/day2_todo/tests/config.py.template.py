# Rename this file to config.py and fill with correct values

FORUM_URL = 'http://forum.address.goes.here'

DB_CONF = {
    'host': 'db.host.com',
    'database': 'database_name_goes_here',
    'user': 'database_user_goes_here',
    'password': 'database_pass_goes_here'
}
