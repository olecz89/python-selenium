import unittest
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import wait
from selenium.webdriver.support.wait import WebDriverWait


class PythonOrgSearch(unittest.TestCase):

    def setUp(self):
        self.driver = webdriver.Firefox()

    def test_search_in_python_org(self):
        driver = self.driver
        driver.get("http://www.python.org")
        self.assertIn("Python", driver.title)
        elem = driver.find_element_by_name("q")
        elem.send_keys("pycon")
        elem.send_keys(Keys.RETURN)
        assert "No results found." not in driver.page_source

    def test_seleniumhq_1(self):
        driver = self.driver
        driver.get("http://www.seleniumhq.org/")
        driver.find_element_by_id("menu_documentation").click()


    def test_demoqa_registration(self):
        driver = self.driver
        driver.get("http://demoqa.com/")
        driver.find_element_by_id("menu-item-374").click()
        WebDriverWait(wait, 5)
        first_name = driver.find_element_by_id("name_3_firstname")
        first_name.send_keys("Alejandro")
        last_name = driver.find_element_by_id("name_3_lastname")
        last_name.send_keys("Czerwony")
        driver.find_element_by_name("radio_4[]").click()
        driver.find_element_by_name("pie_submit").click()







    def tearDown(self):
        self.driver.close()

if __name__ == "__main__":
    unittest.main()