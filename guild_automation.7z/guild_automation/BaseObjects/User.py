class User:

    login = ''
    password = ''
    forename = ''
    surname = ''

    def __init__(self, login='', password='', forename='', surname=''):
        self.login = login
        self.password = password
        self.forename = forename
        self.surname = surname

