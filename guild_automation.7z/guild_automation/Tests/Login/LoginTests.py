import unittest

from selenium import webdriver

from Settings.StageSettings import StageSettings


class Login(unittest.TestCase):
    def setUp(self):
        self.driver = webdriver.Firefox()
        from Settings.StageSettings import StageSettings
        self.driver.get(StageSettings.WEBSITE_ADDRESS)

    def testShouldLoginWithCorrectCredentials(self):
        import time
        logToButton = self.driver.find_element_by_xpath('//*[@id="main-menu"]/ul[2]/li[1]/a')
        logToButton.click()
        time.sleep(3)
        loginText = self.driver.find_element_by_id('login')
        passwordText = self.driver.find_element_by_id('password')
        loginText.send_keys(StageSettings.LINE_MANAGER.login)
        passwordText.send_keys(StageSettings.LINE_MANAGER.password)
        loginButton = self.driver.find_element_by_class_name("btn btn-primary col-sm-12")
        loginButton.click()
        time.sleep(10)

    def tearDown(self):
        self.driver.quit()



