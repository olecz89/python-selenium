from BaseObjects.User import User


class StageSettings:

    STAFF_MANAGER = User(login='staff.manager69', password='pNtKeXSwuVM;|CGS')
    LINE_MANAGER = User(login='line.manager69', password='z@n&b#l^x$x@]s#h')
    ORGANIZATION_MANAGER = User(login='org.manager69', password='9KyXeXrBa[x(E0Oe')

    WEBSITE_ADDRESS = 'https://dante-stage.intive.org/'
